import { Message, MessageVersion } from '@/types/stream';

export class VersionManager {
    // 获取指定消息的所有版本，返回包含用户消息和对应 bot 消息的版本对
    static getMessageVersions(messages: Message[], messageId: string): MessageVersion | null {
        if (!messageId) return null;

        // 1. 查找目标用户消息
        const currentMessage = messages.find(msg => msg.id === messageId);
        if (!currentMessage || currentMessage.type !== 'user') {
            console.log('Not a user message or message not found');
            return null;
        }

        // 2. 获取所有版本的用户消息（基于相同的 parentId 和 version），去重
        const userVersionMap = new Map<number, Message>();
        messages.forEach(msg => {
            if (msg.type === 'user' && msg.parentId === currentMessage.parentId) {
                userVersionMap.set(msg.version || 1, msg);
            }
        });

        // 将去重后的用户消息按 version 排序
        const userVersions = Array.from(userVersionMap.values())
            .sort((a, b) => (a.version || 1) - (b.version || 1));

        // 3. 配对每个用户消息版本的对应 bot 消息
        const versionPairs = userVersions.map(userMsg => ({
            user: userMsg,
            bot: messages.find(botMsg => 
                botMsg.type === 'bot' &&
                botMsg.parentId === userMsg.id
            ) || null
        }));

        // 4. 确定 activeIndex（显示当前 active 状态的版本）
        const activeIndex = versionPairs.findIndex(pair => pair.user.status === 'active');

        return {
            messages: versionPairs,
            activeIndex: activeIndex >= 0 ? activeIndex : 0
        };
    }
}
