import { Message } from '@/types/stream';

export class MessageSyncManager {

    // 更新消息后重新生成用户消息和 bot 消息对
    static updateMessagesAfterEdit(
        messages: Message[],
        editedMessageId: string,
        newContent: string
    ): Message[] {
        const timestamp = Date.now();
        
        return messages.map(msg => {
            const msgId = msg.message_id || msg.id;
            
            if (msgId === editedMessageId) {
                // 更新用户消息内容，设置为最新活跃状态
                return {
                    ...msg,
                    content: newContent,
                    status: 'active',
                    timestamp,
                    isEdited: true
                };
            }
            
            // 标记旧版本为 inactive
            if (msg.original_message_id === editedMessageId) {
                return {
                    ...msg,
                    status: 'inactive'
                };
            }

            // 对应用户消息的 bot 消息，清空内容以准备新的流式内容
            if (msg.type === 'bot' && msg.parentId === editedMessageId) {
                return {
                    ...msg,
                    content: '',
                    isStreaming: true,
                    timestamp,
                    status: 'active'
                };
            }

            return msg;
        });
    }

    // 生成新的用户消息版本和 bot 消息占位符
    static createNewVersion(
        messages: Message[],
        editedMessageId: string,
        newContent: string
    ): Message[] {
        const timestamp = Date.now();

        return messages.map(msg => {
            const msgId = msg.message_id || msg.id;

            if (msgId === editedMessageId) {
                // 创建新的用户消息版本
                return {
                    ...msg,
                    content: newContent,
                    status: 'active',
                    timestamp,
                    isEdited: true
                };
            }

            // 标记旧版本为非活跃
            if (msg.original_message_id === editedMessageId) {
                return {
                    ...msg,
                    status: 'inactive'
                };
            }

            // 为新版本创建 bot 消息占位符
            if (msg.type === 'bot' && msg.parentId === editedMessageId) {
                return {
                    ...msg,
                    content: '',
                    isStreaming: true,
                    timestamp,
                    status: 'active'
                };
            }

            return msg;
        });
    }

    // 更新 bot 消息的流式状态和内容
    static updateStreamingContent(
        messages: Message[],
        parentId: string,
        content: string,
        isStreaming: boolean,
        shouldReset: boolean = false
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' && msg.parentId === parentId) {
                return {
                    ...msg,
                    content: shouldReset ? content : (msg.content || '') + content,
                    isStreaming
                };
            }
            return msg;
        });
    }

    // 重置 bot 消息的内容，准备新的流式输出
    static resetBotMessageContent(
        messages: Message[],
        parentId: string
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' && msg.parentId === parentId) {
                return {
                    ...msg,
                    content: '',
                    isStreaming: true
                };
            }
            return msg;
        });
    }

    // 获取最后一条 bot 消息
    static getLastBotMessage(messages: Message[]): Message | undefined {
        return [...messages]
            .reverse()
            .find(msg => msg.type === 'bot' || msg.role === 'assistant');
    }

    // 更新最后一条 bot 消息的内容
    static updateLastBotMessageContent(
        messages: Message[],
        content: string
    ): Message[] {
        const lastBotMessage = this.getLastBotMessage(messages);
        if (!lastBotMessage) return messages;

        return messages.map(msg => {
            if (msg.id === lastBotMessage.id) {
                return {
                    ...msg,
                    content
                };
            }
            return msg;
        });
    }

    // 更新 bot 消息流状态
    static updateStreamingStatus(
        messages: Message[],
        isStreaming: boolean
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' || msg.role === 'assistant') {
                return {
                    ...msg,
                    isStreaming
                };
            }
            return msg;
        });
    }

    // 查找对应的 bot 回复消息
    static findBotReplyForMessage(
        messages: Message[],
        messageId: string
    ): Message | null {
        return messages.find(msg => 
            (msg.type === 'bot' || msg.role === 'assistant') && 
            msg.parentId === messageId
        ) || null;
    }
}
