import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { toast } from "@/hooks/use-toast";
import MessageNav from "./MessageNav";
import { useChatContext } from "@/app/[上下文]/ChatContext";
import './chat_list.css';
import ErrorMessage from "./chat-list/ErrorMessage";

import UserMessage from "./UserMessage";
import BotMessage from "./BotMessage";
import { ChatListProps, Message } from "@/types/stream";

const MessageItem = memo(({ 
    message,
    allMessages,
    index, 
    isLoading, 
    editingId,
    onEditStart,
    onEditComplete,
    onEditCancel,
    isLastMessage 
}: {
    message: Message;
    allMessages: Message[];
    index: number;
    isLoading?: boolean;
    editingId: string | null;
    onEditStart: (id: string) => void;
    onEditComplete: (id: string, content: string) => Promise<void>;
    onEditCancel: () => void;
    isLastMessage: boolean;
}) => {
    const { getMessageVersions, getCurrentMessagePair } = useChatContext();
    const messageId = message.message_id || message.id;
    
    // 版本相关状态
    const versions = getMessageVersions(messageId || '');
    
    const [currentVersionIndex, setCurrentVersionIndex] = useState(
        versions?.activeIndex || 1
    );

    // 同步 currentVersionIndex 当 versions 变化时
    useEffect(() => {
        if (versions) {
            setCurrentVersionIndex(prev => {
                const newIndex = Math.min(prev, versions.messages.length);
                if (prev !== newIndex) {
                    return newIndex;
                }
                return prev;
            });
        }
    }, [versions]);

    // 获取当前消息对
    const currentPair = useMemo(() => 
        getCurrentMessagePair(message, messageId, currentVersionIndex),
        [message, messageId, currentVersionIndex, getCurrentMessagePair]
    );

    // 版本切换处理
    const handleVersionChange = useCallback((newIndex: number) => {
        if (!versions) {
            console.log('版本信息不存在');
            return;
        }
        
        const selectedVersion = versions.messages[newIndex - 1];
        if (!selectedVersion) {
            console.log(`未找到索引为 ${newIndex - 1} 的版本`);
            return;
        }

        console.log(`切换到版本: ${newIndex}`);
        setCurrentVersionIndex(newIndex);
    }, [versions]);

    const handlePrevVersion = useCallback(() => {
        if (versions && currentVersionIndex > 1) {
            handleVersionChange(currentVersionIndex - 1);
        }
    }, [versions, currentVersionIndex, handleVersionChange]);

    const handleNextVersion = useCallback(() => {
        if (versions && currentVersionIndex < versions.messages.length) {
            handleVersionChange(currentVersionIndex + 1);
        }
    }, [versions, currentVersionIndex, handleVersionChange]);

    const isError = message.type === 'error';
    const isEditing = messageId === editingId;
    const isActive = message.status !== 'inactive';

    // 当消息被编辑时，自动切换到最新版本
    useEffect(() => {
        if (versions && message.isEdited) {
            const latestVersionIndex = versions.messages.length;
            if (currentVersionIndex !== latestVersionIndex) {
                setCurrentVersionIndex(latestVersionIndex);
            }
        }
    }, [versions, message.isEdited, currentVersionIndex]);

    // 编辑完成处理
    const handleEditComplete = async (newContent: string) => {
        try {
            // 立即退出编辑状态
            onEditCancel();
            // 执行修改
            await onEditComplete(message.id!, newContent);
        } catch (error) {
            console.error('修改消息失败:', error);
        }
    };

    if (!isActive) return null;
    if (isError) return <ErrorMessage content={message.content} />;

    return (
        <div className="flex flex-col">
            {/* 用户消息 */}
            <div className={`flex py-3 first:pt-4 last:pb-4 justify-end items-start space-x-5`}>
                <UserMessage
                    message={currentPair.userMessage}
                    isEditing={isEditing}
                    onEdit={() => onEditStart(currentPair.userMessage.id!)}
                    onSave={handleEditComplete}
                    onCancel={onEditCancel}
                />
            </div>
            {/* 版本导航 */}
            {versions && (
                <div className="flex justify-end">
                    <MessageNav
                        currentIndex={currentVersionIndex}
                        totalCount={versions.messages.length}
                        onPrev={handlePrevVersion}
                        onNext={handleNextVersion}
                    />
                </div>
            )}
            {/* Bot 回复 */}
            {currentPair.botMessage && (
                <div className={`flex py-3 first:pt-4 last:pb-4 items-start space-x-4`}>
                    <BotMessage
                        key={currentPair.botMessage.id}
                        content={currentPair.botMessage.content}
                        isLoading={isLoading}
                        isLatestBotMessage={isLastMessage}
                    />
                </div>
            )}
        </div>
    );
});

MessageItem.displayName = 'MessageItem';

export const ChatList = memo(({ isLoading: parentIsLoading, messages, demo }: ChatListProps) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const { modifyMessage, getFilteredMessages } = useChatContext();
    const [showInactiveMessages, setShowInactiveMessages] = useState(false);

    // 使用 useMemo 缓存过滤后的消息
    const localMessages = useMemo(() => {
        console.log('原始消息数量:', messages.length);
        const filtered = getFilteredMessages(showInactiveMessages);
        console.log('过滤后消息数量:', filtered.length);
        console.log('过滤后的消息:', filtered);
        return filtered;
    }, [messages, showInactiveMessages, getFilteredMessages]);

    const handleEdit = useCallback(async (id: string, newContent: string) => {
        try {
            await modifyMessage(id, newContent);
        } catch (error) {
            toast({
                title: '修改消息失败',
                description: '请稍后再试',
                variant: 'destructive',
            });
            console.error('修改消息失败:', error);
        }
        setEditingId(null);
    }, [modifyMessage]);

    const handleEditStart = useCallback((id: string) => {
        setEditingId(id);
    }, []);

    const handleEditCancel = useCallback(() => {
        setEditingId(null);
    }, []);

    return (
        <div className="h-full overflow-hidden w-full">
            <div className="space-y-1">
                <TransitionGroup>
                    {localMessages.map((message, index) => (
                        <CSSTransition 
                            key={message.id || message.message_id}
                            timeout={500} 
                            classNames="message"
                        >
                            <MessageItem
                                message={message}
                                allMessages={messages}
                                index={index}
                                isLoading={parentIsLoading}
                                editingId={editingId}
                                onEditStart={handleEditStart}
                                onEditComplete={handleEdit}
                                onEditCancel={handleEditCancel}
                                isLastMessage={index === localMessages.length - 1}
                            />
                        </CSSTransition>
                    ))}
                </TransitionGroup>
            </div>
        </div>
    );
});

ChatList.displayName = 'ChatList';