// src/app/[上下文]/ChatContext.tsx
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useUser, useAuth } from '@clerk/nextjs';
import { sendMessage as sendMessageAPI } from '@/app/[消息发送]/send_message';
import { fetchHistory } from "@/app/[拉取历史]/fetch_history";
import useTranslation from "@/hooks/useTranslation";
import { useMessageHandler } from '@/hooks/useMessageHandler';
import { useStreamControl } from '@/hooks/useStreamControl';
import { SendMessageResponse, StreamChunk, FinalInfo, Message } from '@/types/stream';
import { User } from '@clerk/nextjs/server';
import { modifyMessage as modifyMessageAPI } from '@/app/[消息修改]/modify_message';
import { VersionManager } from './version-manager';
import { MessageSyncManager } from './message-sync-manager';
import { MessageFilter } from './message-filter';
import { ChatContextProps } from '@/types/chat';

interface MessagePair {
    userMessage: Message;
    botMessage: Message | null;
}

const ChatContext = createContext<ChatContextProps | undefined>(undefined);

export const ChatProvider: React.FC<{ 
    children: React.ReactNode; 
    initialConversationId?: string 
}> = ({ children, initialConversationId }) => {
    const { t } = useTranslation();
    const { user } = useUser();
    const { getToken } = useAuth();
    
    const { 
        messages, 
        setMessages, 
        addMessage, 
        updateLastBotMessage, 
        formatHistoryMessages 
    } = useMessageHandler(user as User | null);

    const {
        isStreaming,
        setIsStreaming,
        abortControllerRef,
        stopStreaming
    } = useStreamControl();

    // 状态管理
    const [conversationId, setConversationId] = useState<string | null>(initialConversationId || null);
    const [newConversationId, setNewConversationId] = useState<string | null>(null);
    const [reloadConversationsCounter, setReloadConversationsCounter] = useState<number>(0);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [hasMore, setHasMore] = useState<boolean>(true);
    const [offset, setOffset] = useState<number>(0);
    const limit = 10;

    const userId = user?.id;

    // 版本管理相关方法
    const getMessageVersions = useCallback((messageId: string) => {
        return VersionManager.getMessageVersions(messages, messageId);
    }, [messages]);

    const findBotReply = useCallback((messageId: string) => {
        return MessageSyncManager.findBotReplyForMessage(messages, messageId);
    }, [messages]);


    // 消息过滤相关方法
    const getFilteredMessages = useCallback((showInactive: boolean = false) => {
        return showInactive 
            ? MessageFilter.filterMessagesByType(messages, 'user')
            : MessageFilter.filterUserMessages(messages);
    }, [messages]);


    // 触发会话重新加载
    const triggerConversationsReload = useCallback(() => {
        setReloadConversationsCounter((prev) => prev + 1);
    }, []);

    // 会话ID变更处理
    useEffect(() => {
        if (initialConversationId !== conversationId) {
            setConversationId(initialConversationId || null);
            setMessages([]);
            setNewConversationId(null);
            setOffset(0);
            setHasMore(true);
        }
    }, [conversationId, initialConversationId, setMessages]);

    // 添加一个标记来防止重复加载
    const [isInitialLoad, setIsInitialLoad] = useState(true);

    // 历史记录获取
    const fetchAndSetHistory = useCallback(async () => {
        if (!conversationId || !userId || !hasMore) return;

        setIsLoading(true);
        console.log('开始获取历史记录，offset:', offset);

        try {
            const history = await fetchHistory({
                user_id: userId,
                conversation_id: conversationId,
                limit,
                offset,
            });

            const formattedMessages = formatHistoryMessages(history.messages);
            console.log('Raw history response:', history.messages.length);
            console.log('Formatted messages:', formattedMessages.length);

            if (formattedMessages.length < limit) {
                setHasMore(false);
            }

            setMessages((prev) => {
                const existingIds = new Set(prev.map(msg => msg.id));
                const uniqueNewMessages = formattedMessages.filter(msg => !existingIds.has(msg.id));
                
                if (uniqueNewMessages.length === 0) {
                    console.log('没有新消息需要添加');
                    return prev;
                }
                
                console.log(`添加 ${uniqueNewMessages.length} 条新消息`);
                return [...prev, ...uniqueNewMessages];
            });

            setOffset((prev) => prev + formattedMessages.length);
        } catch (error) {
            console.error(t('无法加载历史记录'), error);
            setHasMore(false);
        } finally {
            setIsLoading(false);
        }
    }, [conversationId, userId, offset, limit, hasMore, formatHistoryMessages, setMessages, t]);

    // 修改 useEffect
    useEffect(() => {
        if (isInitialLoad && conversationId && userId) {
            fetchAndSetHistory();
            setIsInitialLoad(false);
        }
    }, [isInitialLoad, conversationId, userId, fetchAndSetHistory]);

    // 发送消息
    const sendMessage = async (message: string, inputConversationId?: string) => {
        const activeConversationId = inputConversationId || conversationId;

        if (!userId) {
            addMessage({
                type: 'error',
                content: t('无法发送消息，用户未登录或未授权。'),
                avatarUrl: '',
            });
            return;
        }

        // 创建用户消息和机器人消息
        const userMessage: Message = {
            type: 'user',
            content: message,
            avatarUrl: user?.imageUrl || 'https://github.com/shuakami.png',
        };
        const botMessage: Message = {
            type: 'bot',
            content: '',
            avatarUrl: 'https://api.dicebear.com/6.x/bottts/svg?seed=Felix',
            isStreaming: true,
        };

        setMessages(prev => [...prev, userMessage, botMessage]);
        setIsLoading(true);
        setIsStreaming(true);

        const abortController = new AbortController();
        abortControllerRef.current = abortController;

        try {
            const token = await getToken();
            if (!token) throw new Error(t('无法获取 JWT，用户未授权'));

            let currentConversationId: string | null = activeConversationId;
            let currentMessageId: string | null | undefined = null;

            await sendMessageAPI(
                {
                    user_input: message,
                    user_id: userId,
                    conversation_id: activeConversationId || undefined,
                },
                token,
                (initialResponse: SendMessageResponse) => {
                    currentConversationId = initialResponse.conversation_id;
                    currentMessageId = initialResponse.message_id;
                    if (!conversationId) {
                        setConversationId(currentConversationId);
                    }
                },
                (chunk: StreamChunk) => {
                    if (chunk.content) {
                        setIsLoading(false);
                        updateLastBotMessage(chunk.content);
                    }

                    if (chunk.is_final_chunk) {
                        setMessages(prevMessages => 
                            MessageSyncManager.updateStreamingStatus(prevMessages, false)
                        );
                        setIsStreaming(false);
                        setNewConversationId(currentConversationId);
                        triggerConversationsReload();
                    }
                },
                (finalInfo: FinalInfo) => {
                    console.log('最终信息:', finalInfo);
                },
                (error: any) => {
                    console.error(t('后端错误:'), error);
                    updateLastBotMessage(t('抱歉，发送消息失败。'));
                    setIsStreaming(false);
                    setIsLoading(false);
                },
                abortController.signal
            );
        } catch (error) {
            console.error(t('发送消息失败:'), error);
            updateLastBotMessage(t('抱歉，发送消息失败。'));
            setIsStreaming(false);
            setIsLoading(false);
        } finally {
            abortControllerRef.current = null;
        }
    };

    // 加载更多消息
    const loadMoreMessages = useCallback(() => {
        if (!isLoading && hasMore) {
            fetchAndSetHistory();
        }
    }, [isLoading, hasMore, fetchAndSetHistory]);

    // 重置新会话ID
    const resetNewConversationId = useCallback(() => {
        setNewConversationId(null);
    }, []);

    // 修改消息
    const modifyMessage = async (messageId: string, newContent: string) => {
        if (!userId || !conversationId) {
            addMessage({
                type: 'error',
                content: t('无法修改消息，用户未登录或未授权。'),
                avatarUrl: '',
            });
            return;
        }

        // 1. 立即更新用户消息并创建新版本
        setMessages(prevMessages => 
            MessageSyncManager.createNewVersion(prevMessages, messageId, newContent)
        );
        setIsStreaming(true);

        const abortController = new AbortController();
        abortControllerRef.current = abortController;

        try {
            const token = await getToken();
            if (!token) throw new Error(t('无法获取 JWT，用户未授权'));

            let accumulatedContent = '';

            await modifyMessageAPI(
                {
                    conversation_id: conversationId,
                    message_id: messageId,
                    user_id: userId,
                    new_content: newContent,
                },
                token,
                (initialResponse: SendMessageResponse) => {
                    // 初始响应时重置 bot 消息内容
                    setMessages(prevMessages => 
                        MessageSyncManager.resetBotMessageContent(prevMessages, messageId)
                    );
                },
                (chunk: StreamChunk) => {
                    if (chunk.content) {
                        // 累加内容
                        accumulatedContent += chunk.content;
                        setMessages(prevMessages => 
                            MessageSyncManager.updateStreamingContent(
                                prevMessages,
                                messageId,
                                chunk.content,
                                true,
                                accumulatedContent === chunk.content
                            )
                        );
                    }

                    if (chunk.is_final_chunk) {
                        // 最终更新，使用完整的内容
                        setMessages(prevMessages => 
                            MessageSyncManager.updateStreamingContent(
                                prevMessages,
                                messageId,
                                accumulatedContent,
                                false,
                                true
                            )
                        );
                        setIsStreaming(false);
                        triggerConversationsReload();
                    }
                },
                (finalInfo: FinalInfo) => {
                    console.log('最终信息:', finalInfo);
                },
                (error: any) => {
                    console.error(t('修改消息失败:'), error);
                    setIsStreaming(false);
                },
                abortController.signal
            );
        } catch (error) {
            console.error(t('修改消息失败:'), error);
            setIsStreaming(false);
        } finally {
            abortControllerRef.current = null;
        }
    };

    // 新增版本管理相关方法
    const getCurrentMessagePair = useCallback((
        message: Message,
        messageId: string | undefined,
        versionIndex: number
    ): MessagePair => {
        const versions = getMessageVersions(messageId || '');
        
        if (versions && versions.messages[versionIndex - 1]) {
            return {
                userMessage: versions.messages[versionIndex - 1].user || message,
                botMessage: versions.messages[versionIndex - 1].bot || null
            };
        }
        
        return {
            userMessage: message,
            botMessage: messageId ? findBotReply(messageId) : null
        };
    }, [getMessageVersions, findBotReply]);

    return (
        <ChatContext.Provider value={{
            messages,
            sendMessage,
            addMessage,
            triggerConversationsReload,
            reloadConversationsCounter,
            newConversationId,
            resetNewConversationId,
            isLoading,
            loadMoreMessages,
            isStreaming,
            stopStreaming: () => stopStreaming(conversationId, user?.id || null, messages, setMessages),
            conversationId,
            modifyMessage,
            getMessageVersions,
            findBotReply,
            getFilteredMessages,
            getCurrentMessagePair,
        }}>
            {children}
        </ChatContext.Provider>
    );
};

export const useChatContext = () => {
    const context = useContext(ChatContext);
    if (!context) {
        throw new Error('useChatContext 必须在 ChatProvider 内使用');
    }
    return context;
};