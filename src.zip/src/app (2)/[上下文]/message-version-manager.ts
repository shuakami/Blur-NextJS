import { Message } from '@/types/stream';

interface MessagePair {
    user: Message;
    bot: Message | null;
}

interface VersionInfo {
    pairs: MessagePair[];
    activeVersion: number;
    totalVersions: number;
}

export class MessageVersionManager {
    // 获取消息的所有版本信息
    static getVersionInfo(messages: Message[], originalMessageId: string): VersionInfo | null {
      // 日志
        // 找到所有相关版本的消息
        const relatedMessages = messages.filter(msg => 
            msg.original_message_id === originalMessageId
        );

        if (!relatedMessages.length) return null;

        // 按版本号分组
        const versionGroups = new Map<number, MessagePair>();
        
        relatedMessages.forEach(msg => {
            const version = msg.edit_version;
            if (!versionGroups.has(version)) {
                versionGroups.set(version, { user: null!, bot: null });
            }
            
            const pair = versionGroups.get(version)!;
            if (msg.role === 'user' || msg.type === 'user') {
                pair.user = msg;
            } else if (msg.role === 'assistant' || msg.type === 'bot') {
                pair.bot = msg;
            }
        });

        // 转换为数组并排序
        const pairs = Array.from(versionGroups.entries())
            .sort(([a], [b]) => a - b)
            .map(([_, pair]) => pair);

        // 找到当前激活的版本
        const activeVersion = pairs.findIndex(pair => 
            pair.user.status === 'active' || (pair.bot && pair.bot.status === 'active')
        );

        return {
            pairs,
            activeVersion: activeVersion >= 0 ? activeVersion : pairs.length - 1,
            totalVersions: pairs.length
        };
    }

    // 获取特定版本的消息对
    static getVersionPair(messages: Message[], originalMessageId: string, version: number): MessagePair | null {
        const versionInfo = this.getVersionInfo(messages, originalMessageId);
        if (!versionInfo || version >= versionInfo.totalVersions) return null;
        return versionInfo.pairs[version];
    }

    // 获取当前激活的消息对
    static getActiveVersionPair(messages: Message[], originalMessageId: string): MessagePair | null {
        const versionInfo = this.getVersionInfo(messages, originalMessageId);
        if (!versionInfo) return null;
        return versionInfo.pairs[versionInfo.activeVersion];
    }

    // 创建新版本
    static createNewVersion(
        messages: Message[],
        originalMessageId: string,
        newUserContent: string
    ): Message[] {
        const versionInfo = this.getVersionInfo(messages, originalMessageId);
        if (!versionInfo) return messages;

        const newVersion = versionInfo.totalVersions;
        const timestamp = Date.now();

        return messages.map(msg => {
            if (msg.original_message_id === originalMessageId) {
                // 将所有旧版本标记为 inactive
                return {
                    ...msg,
                    status: 'inactive'
                };
            }
            return msg;
        }).concat([
            // 添加新的用户消息
            {
                message_id: crypto.randomUUID(),
                content: newUserContent,
                role: 'user',
                timestamp,
                status: 'active',
                original_message_id: originalMessageId,
                edit_version: newVersion
            },
            // 添加新的 bot 消息占位符
            {
                message_id: crypto.randomUUID(),
                content: '',
                role: 'assistant',
                timestamp,
                status: 'active',
                original_message_id: originalMessageId,
                edit_version: newVersion,
                isStreaming: true
            }
        ]);
    }
} 