// src/app/[上下文]/message-filter.ts
import { Message } from '@/types/stream';

export class MessageFilter {

    static filterUserMessages(messages: Message[]): Message[] {
        return messages.filter(msg => 
            msg.type === 'user' && 
            msg.status !== 'inactive'
        );
    }

    static filterActiveMessages(messages: Message[]): Message[] {
        return messages.filter(msg => msg.status !== 'inactive');
    }

    static filterMessagesByType(
        messages: Message[], 
        type: 'user' | 'bot' | 'error'
    ): Message[] {
        return messages.filter(msg => msg.type === type);
    }

    static filterMessagesByStatus(
        messages: Message[], 
        status: 'active' | 'inactive'
    ): Message[] {
        return messages.filter(msg => msg.status === status);
    }
}
