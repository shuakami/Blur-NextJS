import { Message } from '@/types/stream';

export class MessageSyncManager {
    static updateMessagesAfterEdit(
        messages: Message[],
        editedMessageId: string,
        newContent: string
    ): Message[] {
        return messages.map(msg => {
            const msgId = msg.message_id || msg.id;
            if (msgId === editedMessageId) {
                return {
                    ...msg,
                    content: newContent,
                    status: 'active' as const,
                    timestamp: Date.now()
                };
            }
            // 将相关的旧消息标记为 inactive
            if (msg.parentId === editedMessageId || 
                (msg.childrenIds && msg.childrenIds.includes(editedMessageId))) {
                return {
                    ...msg,
                    status: 'inactive' as const
                };
            }
            return msg;
        });
    }

    static findBotReplyForMessage(
        messages: Message[],
        messageId: string
    ): Message | null {
        return messages.find(msg => 
            (msg.type === 'bot' || msg.role === 'assistant') && 
            msg.parentId === messageId
        ) || null;
    }

    // 新增：更新消息流状态的方法
    static updateStreamingStatus(
        messages: Message[],
        isStreaming: boolean
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' || msg.role === 'assistant') {
                return {
                    ...msg,
                    isStreaming
                };
            }
            return msg;
        });
    }

    // 新增：获取最后一条机器人消息
    static getLastBotMessage(messages: Message[]): Message | undefined {
        return [...messages]
            .reverse()
            .find(msg => msg.type === 'bot' || msg.role === 'assistant');
    }

    // 新增：更新最后一条机器人消息的内容
    static updateLastBotMessageContent(
        messages: Message[],
        content: string
    ): Message[] {
        const lastIndex = messages.length - 1;
        return messages.map((msg, index) => {
            if (index === lastIndex && (msg.type === 'bot' || msg.role === 'assistant')) {
                return {
                    ...msg,
                    content
                };
            }
            return msg;
        });
    }

    // 创建新版本的消息对
    static createNewVersion(
        messages: Message[],
        editedMessageId: string,
        newContent: string
    ): Message[] {
        const timestamp = Date.now();
        return messages.map(msg => {
            const msgId = msg.message_id || msg.id;
            
            if (msgId === editedMessageId) {
                // 更新用户消息
                return {
                    ...msg,
                    content: newContent,
                    status: 'active',
                    timestamp,
                    isEdited: true
                };
            }
            
            // 将旧版本标记为非活跃
            if (msg.parentId === editedMessageId || 
                (msg.childrenIds && msg.childrenIds.includes(editedMessageId))) {
                return {
                    ...msg,
                    status: 'inactive'
                };
            }

            // 为编辑的消息创建新的 bot 回复占位
            if (msg.type === 'bot' && msg.parentId === editedMessageId) {
                return {
                    ...msg,
                    content: '',
                    isStreaming: true,
                    timestamp,
                    status: 'active'
                };
            }

            return msg;
        });
    }

    // 更新流式状态和内容
    static updateStreamingContent(
        messages: Message[],
        parentId: string,
        content: string,
        isStreaming: boolean,
        shouldReset: boolean = false
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' && msg.parentId === parentId) {
                return {
                    ...msg,
                    content: shouldReset ? content : (msg.content || '') + content,
                    isStreaming
                };
            }
            return msg;
        });
    }

    // 新增：重置 bot 消息内容
    static resetBotMessageContent(
        messages: Message[],
        parentId: string
    ): Message[] {
        return messages.map(msg => {
            if (msg.type === 'bot' && msg.parentId === parentId) {
                return {
                    ...msg,
                    content: '',
                    isStreaming: true
                };
            }
            return msg;
        });
    }
}