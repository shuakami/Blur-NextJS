import { Message, MessageVersion } from "@/types/stream";

export class VersionManager {
    // 使用 WeakMap 作为缓存，当消息对象不再被引用时自动清理
    private static cache = new WeakMap<Message[], Map<string, MessageVersion>>();

    static getMessageVersions(messages: Message[], messageId: string): MessageVersion | null {
        // 1. 检查缓存
        let messageCache = VersionManager.cache.get(messages);
        if (messageCache?.has(messageId)) {
            return messageCache.get(messageId)!;
        }

        if (!messageId) return null;

        // 2. 查找目标用户消息
        const currentMessage = messages.find(msg => msg.id === messageId);
        if (!currentMessage || currentMessage.type !== 'user') return null;

        // 3. 使用 Map 优化版本查找
        const userVersionMap = new Map<number, Message>();
        const relatedMessages = messages.filter(msg => 
            msg.parentId === currentMessage.parentId
        );

        // 4. 一次遍历收集所有相关消息
        for (const msg of relatedMessages) {
            if (msg.type === 'user') {
                userVersionMap.set(msg.version || 1, msg);
            }
        }

        // 5. 将用户消息按版本排序
        const userVersions = Array.from(userVersionMap.values())
            .sort((a, b) => (a.version || 1) - (b.version || 1));

        // 6. 配对 bot 消息（使用 Map 优化查找）
        const botMessagesMap = new Map(
            messages
                .filter(msg => msg.type === 'bot')
                .map(msg => [msg.parentId, msg])
        );

        const versionPairs = userVersions.map(userMsg => ({
            user: userMsg,
            bot: botMessagesMap.get(userMsg.id!) || null
        }));

        // 7. 确定 activeIndex
        const activeIndex = versionPairs.findIndex(pair => 
            pair.user.status === 'active'
        );

        const result = {
            messages: versionPairs,
            activeIndex: activeIndex >= 0 ? activeIndex + 1 : 1
        };

        // 8. 更新缓存
        if (!messageCache) {
            messageCache = new Map();
            this.cache.set(messages, messageCache);
        }
        messageCache.set(messageId, result);

        return result;
    }
}