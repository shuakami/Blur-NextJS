// src/api/config.ts
import axios from 'axios';
import {ApiError, ErrorCode} from "@/types/error";

const apiClient = axios.create({
    // 如果是生产环境，读取NEXT_PUBLIC_PROD_API_URL，不是就读取NEXT_PUBLIC_LOCAL_API_URL
    baseURL: process.env.NODE_ENV === 'production'
        ? process.env.NEXT_PUBLIC_PROD_API_URL
        : process.env.NEXT_PUBLIC_LOCAL_API_URL,
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json',
    },
});


export const setupApiClientAuth = (getToken: () => Promise<string | null>) => {
    apiClient.interceptors.request.use(
        async (config) => {
            try {
                const token = await getToken();

                if (token) {
                    config.headers['Authorization'] = `Bearer ${token}`;
                } else {
                    return Promise.reject({
                        code: ErrorCode.LoginError,
                        message: "You are not logged in.",
                    });
                }

                return config;
            } catch (error) {
                return Promise.reject({
                    code: ErrorCode.NetworkError,
                    message: "Error getting authentication token",
                });
            }
        },
        (error) => {
            return Promise.reject(error);
        }
    );

    apiClient.interceptors.response.use(
        (response) => {
            return response;
        },
        (error) => {
            const apiError: ApiError = {
                code: ErrorCode.NetworkError,
                message: (error as Error).message || "Network Error",
            };

            if (error.response) {
                apiError.code = error.response.status === 404 ? ErrorCode.NotFound :
                    error.response.status === 401 ? ErrorCode.LoginError :
                        error.response.status === 403 ? ErrorCode.Forbidden :
                            error.response.status === 500 ? ErrorCode.InternalServerError :
                                error.response.status === 422 ? ErrorCode.UnprocessableEntity :
                                    error.response.status === 408 ? ErrorCode.Timeout :
                                        error.response.status === 429 ? ErrorCode.TooManyRequests :
                                            error.response.status === 400 ? ErrorCode.BadRequest : ErrorCode.NetworkError;
            }

            const event = new CustomEvent("apiError", {detail: apiError});
            window.dispatchEvent(event);

            return Promise.reject(apiError);
        }
    );
};

export default apiClient;