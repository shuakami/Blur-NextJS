import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { toast } from "@/hooks/use-toast";
import MessageNav from "./MessageNav";
import { useChatContext } from "@/app/[上下文]/ChatContext";
import './chat_list.css';
import ErrorMessage from "./chat-list/ErrorMessage";

import UserMessage from "./UserMessage";
import BotMessage from "./BotMessage";
import { ChatListProps, Message } from "@/types/stream";

const MessageItem = memo(({ 
    currentPair,
    versions,
    currentVersionIndex,
    isLoading,
    isEditing,
    onEdit,
    onSave,
    onCancel,
    onVersionChange,
    isLastMessage 
}: {
    currentPair: { userMessage: Message; botMessage?: Message };
    versions?: { messages: Message[]; activeIndex: number };
    currentVersionIndex: number;
    isLoading?: boolean;
    isEditing: boolean;
    onEdit: () => void;
    onSave: (content: string) => Promise<void>;
    onCancel: () => void;
    onVersionChange: (newIndex: number) => void;
    isLastMessage: boolean;
}) => {

    console.log('currentPair', currentPair);
    
    const handlePrevVersion = useCallback(() => {
        if (versions && currentVersionIndex > 1) {
            onVersionChange(currentVersionIndex - 1);
        }
    }, [versions, currentVersionIndex, onVersionChange]);

    const handleNextVersion = useCallback(() => {
        if (versions && currentVersionIndex < versions.messages.length) {
            onVersionChange(currentVersionIndex + 1);
        }
    }, [versions, currentVersionIndex, onVersionChange]);

    if (!currentPair.userMessage) return null;

    return (
        <div className="flex flex-col">
            <div className={`flex py-3 first:pt-4 last:pb-4 justify-end items-start space-x-5`}>
                <UserMessage
                    message={currentPair.userMessage}
                    isEditing={isEditing}
                    onEdit={onEdit}
                    onSave={onSave}
                    onCancel={onCancel}
                />
            </div>
            {versions && (
                <div className="flex justify-end">
                    <MessageNav
                        currentIndex={currentVersionIndex}
                        totalCount={versions.messages.length}
                        onPrev={handlePrevVersion}
                        onNext={handleNextVersion}
                    />
                </div>
            )}
            {currentPair.botMessage && (
                <div className={`flex py-3 first:pt-4 last:pb-4 items-start space-x-4`}>
                    <BotMessage
                        key={currentPair.botMessage.id}
                        content={currentPair.botMessage.content}
                        isLoading={isLoading}
                        isLatestBotMessage={isLastMessage}
                    />
                </div>
            )}
        </div>
    );
}, (prevProps, nextProps) => {
    return (
        prevProps.currentPair === nextProps.currentPair &&
        prevProps.currentVersionIndex === nextProps.currentVersionIndex &&
        prevProps.isLoading === nextProps.isLoading &&
        prevProps.isEditing === nextProps.isEditing &&
        prevProps.isLastMessage === nextProps.isLastMessage
    );
});

export const ChatList = memo(({ isLoading: parentIsLoading, messages, demo }: ChatListProps) => {
    const [editingId, setEditingId] = useState<string | null>(null);
    const { modifyMessage, getFilteredMessages, getMessageVersions, getCurrentMessagePair } = useChatContext();
    const [showInactiveMessages, setShowInactiveMessages] = useState(false);
    const [versionIndices, setVersionIndices] = useState<Record<string, number>>({});
    
    // 添加 ref 来追踪重渲染
    const renderCount = useRef(0);
    const previousMessages = useRef(messages);
    
    useEffect(() => {
        renderCount.current += 1;
        console.log('ChatList 重渲染次数:', renderCount.current);
        
        // 检查消息是否真的发生变化
        if (messages !== previousMessages.current) {
            console.log('消息发生变化:', {
                oldLength: previousMessages.current?.length,
                newLength: messages?.length
            });
            previousMessages.current = messages;
        }
    });

    // 使用 useCallback 缓存 getFilteredMessages 的参数
    const getFilteredMessagesCallback = useCallback((show: boolean) => {
        console.log('获取过滤消息, showInactive:', show);
        return getFilteredMessages(show);
    }, [getFilteredMessages]);

    // 使用 useMemo 缓存过滤后的消息，添加深度比较
    const localMessages = useMemo(() => {
        console.log('重新计算 localMessages');
        return getFilteredMessagesCallback(showInactiveMessages);
    }, [showInactiveMessages, getFilteredMessagesCallback]);

    // 缓存版本获取函数
    const getMessageVersionsMemo = useCallback((messageId: string) => {
        console.log('获取消息版本, messageId:', messageId);
        return getMessageVersions(messageId);
    }, [getMessageVersions]);

    // 缓存获取当前消息对的函数
    const getCurrentMessagePairMemo = useCallback((message: Message, messageId: string, versionIndex: number) => {
        console.log('获取当前消息对:', { messageId, versionIndex });
        return getCurrentMessagePair(message, messageId, versionIndex);
    }, [getCurrentMessagePair]);

    // 处理消息对和版本信息，添加防抖
    const messageData = useMemo(() => {
        console.log('重新计算 messageData');
        return localMessages.map(message => {
            const messageId = message.message_id || message.id;
            const versions = getMessageVersionsMemo(messageId || '');
            const currentVersionIndex = versionIndices[messageId || ''] || versions?.activeIndex || 1;
            const currentPair = getCurrentMessagePairMemo(message, messageId, currentVersionIndex);
            
            return {
                message,
                versions,
                currentVersionIndex,
                currentPair,
                messageId
            };
        });
    }, [localMessages, getMessageVersionsMemo, getCurrentMessagePairMemo, versionIndices]);

    const handleVersionChange = useCallback((messageId: string, newIndex: number) => {
        console.log('版本变更:', { messageId, newIndex });
        setVersionIndices(prev => ({
            ...prev,
            [messageId]: newIndex
        }));
    }, []);

    const handleEdit = useCallback(async (id: string, newContent: string) => {
        console.log('编辑消息:', { id, newContent });
        try {
            await modifyMessage(id, newContent);
        } catch (error) {
            console.error('修改消息失败:', error);
            toast({
                title: '修改消息失败',
                description: '请稍后再试',
                variant: 'destructive',
            });
        }
        setEditingId(null);
    }, [modifyMessage]);

    // 缓存渲染项目的回调函数
    const renderMessageItem = useCallback((data: typeof messageData[0], index: number) => {
        const { message, versions, currentVersionIndex, currentPair, messageId } = data;
        return (
            <CSSTransition 
                key={messageId}
                timeout={500} 
                classNames="message"
            >
                <MessageItem
                    currentPair={currentPair}
                    versions={versions}
                    currentVersionIndex={currentVersionIndex}
                    isLoading={parentIsLoading}
                    isEditing={messageId === editingId}
                    onEdit={() => setEditingId(messageId)}
                    onSave={(content) => handleEdit(messageId, content)}
                    onCancel={() => setEditingId(null)}
                    onVersionChange={(newIndex) => handleVersionChange(messageId, newIndex)}
                    isLastMessage={index === messageData.length - 1}
                />
            </CSSTransition>
        );
    }, [parentIsLoading, editingId, handleEdit, handleVersionChange]);

    if (!messages || messages.length === 0) {
        return <div>No messages available</div>;
    }

    return (
        <div className="h-full overflow-hidden w-full">
            <div className="space-y-1">
                <TransitionGroup>
                    {messageData.map(renderMessageItem)}
                </TransitionGroup>
            </div>
        </div>
    );
});

MessageItem.displayName = 'MessageItem';
ChatList.displayName = 'ChatList';